jQuery(document).ready(function($) {

	function clearInputValues() {
		$.fn.cleardefault = function() {
			return this.focus(function() {
				if (this.value == this.defaultValue) {
					this.value = "";
				}
			}).blur(function() {
				if (!this.value.length) {
					this.value = this.defaultValue;
				}
			});
		};
		$(".clearit input[type='text'], .clearit textarea").cleardefault();
	}

	function createDownloadTabs() {
		$(".tab-content").hide(); //Hide all content
		if (location.hash != "") {
			var target = "#" + location.hash.split("#")[1]; // need semicolon at end of line
			$(location.hash).show(); //Show first tab content
			$("ul.tabs li:has(a[href=" + target + "])").addClass("active").show(); //need '+' either side of 'target'
		} else {
			$("ul.tabs li:first").addClass("active").show(); //Activate first tab
			$(".tab-content:first").show(); //Show first tab content
		}

		//On Click Event
		$("ul.tabs li").click(function() {

			$("ul.tabs li").removeClass("active"); //Remove any "active" class
			$(this).addClass("active"); //Add "active" class to selected tab
			$(".tab-content").hide(); //Hide all tab content

			var activeTab = $(this).find("a").attr("href"); //Find the href attribute value to identify the active tab + content
			$(activeTab).fadeIn(); //Fade in the active ID content
			return false;
		});
	}

	function createMobileDropdown() {
		var footerNavContainer = $('footer nav');
		var footerNav = $('#menu-footer-nav');
		var navToggle = $('<div class="footer-toggle"><span class="footer-nav-toggle"></span></div>');

		$(footerNavContainer).prepend(navToggle);
		$(navToggle).click(function() {
			footerNav.slideToggle();
		});
	}

	function animateIntro() {
		$(".plus, .cloud").each(function(i) {

			$(this).delay(2500);
			$(this).delay(i * 600).fadeIn(800);
		});
	}

	function animateHeader() {
		$('.nav-wrap').animate({
			top: 0
		}, 2000).queue(function(next) {
			$(".main-nav").fadeTo(1500, 1);
		});
	}


	function createSpans() {
		$("a.button").prepend("<span></span>");
		$("a#toTop").prepend("<span></span>");
		$(".nav-dock a").prepend("<span></span>");
		$(".single-nav-links a").prepend("<span></span>");
	}

	$(".services-intro a").hover(function() { // When mouse pointer is above the link
		// Make the image inside link to be transparent
		$(this).stop().fadeTo("fast", 0.7);
	}, function() { // When mouse pointer move out of the link
		// Return image to its previous state
		$(this).stop().fadeTo("fast", 1);
	});

	function initializeScrollTop() {
		$("#toTop").scrollToTop({
			speed: 1000,
			ease: "swing",
			start: 800
		});
	}


	function createMobileNav() {
		var navContainer = $('header .menu-main-nav-container');
		var nav = $('#menu-main-nav');
		var navToggle = $('<div class="nav-toggle-wrap"><span class="button nav-toggle">Navigation</span></div>');

		$(navContainer).prepend(navToggle);
		$(navToggle).click(function() {
			nav.slideToggle();
		});
	}


	function startFancyBox() {
		$(".fancy").fancybox({
			prevEffect: 'fade',
			nextEffect: 'fade',
			closeBtn: true,
			helpers: {
				title: {
					type: 'outside'
				},
				thumbs: {
					width: 50,
					height: 50
				}
			}
		});
	}
	// End function Definitions

	if ($.cookie('homeAnimate') == null) {
		animateIntro();
		animateHeader();
		$.cookie('homeAnimate', 'true', {
			expires: 1
		});
	} else {
		$('.nav-wrap, .plus, .cloud, .home .main-nav').addClass('noAnimate');
	}


	// Initiate all scripts
	clearInputValues();
	createDownloadTabs();
	createMobileDropdown();

	createSpans();
	initializeScrollTop();
	startFancyBox();
	createMobileNav();
	//End Document Ready

	var divs = $('header');
	$(window).scroll(function() {
		if ($(window).scrollTop() < 70) {
			divs.stop().animate({
				'top': '0px'
			}, 300);
		} else {
			divs.stop().animate({
				'top': '-165px'
			}, 300);
		}
	});

	// ADD CURRENT CLASS TO FIRST SECTION 
	if(!$('.section').hasClass('current')) {
		$('.section:first').addClass('current');
	}
	// PROJECT :: INITIALIZE WAYPOINT
	$('.section')
		.waypoint(function(direction) {
			if(direction == 'down') {
				$('.section').removeClass('current');
				$(this).addClass('current');
			}
		})
		.waypoint(function(direction) {
			if(direction == 'up') {
				$('.section').removeClass('current');
				$(this).addClass('current');
			}
		}, {
			offset: function() {
				return (-$(this).height() - 50);
		  	}
		});

	
	// PROJECT :: NEXT BUTTON
	$('#port-arrows #next').click(function () {
		// IF CURRENT SECTION IS THE HERO SHOT
		if($('.current').attr('id') == "intro") {
			$('html, body').animate({
				scrollTop: $('section.portfolio .section:first').offset().top
			}, 500);	
		}
		// IF CURRENT SECTION IS IN THE STACK OF IMAGES
		if($('.current').parent().attr('id') == "gallery") {
			// IF CURRENT SECTION IS THE LAST IMAGE(S) IN THE STACK
			if($('.current').is(':last-child')) { 
				// IF THERE IS A GALLERY
				if($('#gallery').is(':visible')) {
					$('html, body').animate({
						scrollTop: $('#gallery').offset().top + 2
					}, 500);
				// IF THERE ISN'T A GALLERY
				} else {
					$('html, body').animate({ scrollTop: 0 }, 500);
				}
			// IF THE CURRENT SECTION IS NOT THE LAST IMAGE(S) IN THE STACK
			} else {
				$('html, body').animate({
					scrollTop: $('.current').next('.section').offset().top
				}, 500);
			}
		}
		// IF AT THE BOTTOM OF THE PAGE
		if($(window).scrollTop() + $(window).height() == $(document).height()) {
		   $('html, body').animate({ scrollTop: 0 }, 500);
	   	}
		return false;
	});
	
	// PROJECT :: PREVIOUS BUTTON
	$('#port-arrows #prev').click(function () {
		// IF CURRENT SECTION IS THE HERO SHOT
		if($('.current').attr('id') == "intro") {
			// IF THERE IS A GALLERY
			if($('#gallery').is(':visible')) {
				$('html, body').animate({
					scrollTop: $('#gallery').offset().top + 2
				}, 500);
			// IF THERE ISN'T A GALLERY
			} else {
				$('html, body').animate({
					scrollTop: $('#gallery .section:last-child').offset().top
				}, 500);
			}	
		}
		// IF CURRENT SECTION IS IN THE STACK OF IMAGES
		if($('.current').parent().attr('id') == "gallery") {
			// IF CURRENT SECTION IS THE first IMAGE(S) IN THE STACK
			if($('.current').is(':first-child')) { 
				$('html, body').animate({ scrollTop: 0 }, 500);
			// IF THE CURRENT SECTION IS NOT THE FIRST IMAGE(S) IN THE STACK
			} else {
				$('html, body').animate({
					scrollTop: $('.current').prev('.section').offset().top
				}, 500);
			}
		}
		return false;		
	});


});